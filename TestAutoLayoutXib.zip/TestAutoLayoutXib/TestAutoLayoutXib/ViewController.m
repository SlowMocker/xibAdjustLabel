//
//  ViewController.m
//  TestAutoLayoutXib
//
//  Created by Wu on 17/5/25.
//  Copyright © 2017年 Wu. All rights reserved.
//

#import "ViewController.h"
#import "CHDisclosureIndicatorView.h"
#import <Masonry.h>


@interface ViewController ()<CHDisclosureIndicatorViewDelegate>

@property (nonatomic , strong) UIView *topView;

@property (nonatomic , strong) CHDisclosureIndicatorView *diView;

@property (nonatomic , strong) UIView *btView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor darkGrayColor];
    
    [self.view addSubview:self.topView];
    [self.view addSubview:self.diView];
    [self.view addSubview:self.btView];
}

- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.topView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(30);
        make.left.mas_equalTo(15);
        make.right.mas_equalTo(-15);
        make.height.mas_equalTo(70);
    }];
    
    [self.diView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.topView.mas_bottom).offset(10);
        make.left.mas_equalTo(15);
        make.right.mas_equalTo(-15);
        make.height.mas_greaterThanOrEqualTo(50);
    }];
    
    [self.btView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.diView.mas_bottom).offset(10);
        make.left.mas_equalTo(15);
        make.right.mas_equalTo(-15);
        make.height.mas_equalTo(70);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

static NSInteger num = 0;
- (void) didSelectedDisclosureIndicatorView:(CHDisclosureIndicatorView *)disclosureIndicatorView indexPath:(CHIndexPath *)indexPath {
    switch (num) {
        case 0:
        {
            _diView.title = @"朋友十年";
            _diView.attributedIndicator = [self attributedStrWithFaultCode:@"新街口演唱" faultCodeVal:@"大风大雨都跑到脑后\n因为有朋友\n人生一杯酒"];
            break;
        }
        case 1:
        {
            _diView.title = @"你瞒我瞒";
            _diView.indicator = @"林夕作词\n陈柏宇演唱\n这若是浪漫\n我怎么觉得就快分离\n你哭过\n但眼影闪的更艳美\n我是谁情人\n你始终还是你\n微笑静默互望\n笑比哭更可悲";
            break;
        }
        case 2:
        {
            _diView.title = @"你瞒我瞒";
            _diView.indicator = @"笑比哭更可悲";
            break;
        }
        default:
        {
            num = 0;
            _diView.title = @"朋友十年";
            _diView.attributedIndicator = [self attributedStrWithFaultCode:@"新街口演唱" faultCodeVal:@"人生一杯酒"];
            return;
        }
            break;
    }
    num ++;
    
}



- (UIView *) topView {
    if (_topView == nil) {
        _topView = [[UIView alloc]init];
        _topView.backgroundColor = [UIColor blueColor];
        _topView.layer.cornerRadius = 5;
    }
    return _topView;
}

- (CHDisclosureIndicatorView *) diView {
    if (_diView == nil) {
        _diView = [[[UINib nibWithNibName:@"CHDisclosureIndicatorView" bundle:nil] instantiateWithOwner:nil options:nil] lastObject];
        _diView.layer.cornerRadius = 5;
        _diView.delegate = self;
        _diView.title = @"默默";
        _diView.indicator = nil;
        _diView.indexPath.section = 0;
        _diView.indexPath.row = 0;
    }
    return _diView;
}

- (UIView *) btView {
    if (_btView == nil) {
        _btView = [[UIView alloc]init];
        _btView.backgroundColor = [UIColor yellowColor];
        _btView.layer.cornerRadius = 5;
    }
    return _btView;
}

- (NSAttributedString *) attributedStrWithFaultCode:(NSString *)faultCode faultCodeVal:(NSString *)faultCodeVal {
    NSMutableAttributedString * faultCode_ = [[NSMutableAttributedString alloc] initWithString:faultCode];
    NSDictionary * faultCodeAttributes = @{ NSFontAttributeName:[UIFont boldSystemFontOfSize:14],NSForegroundColorAttributeName:[UIColor redColor],};
    [faultCode_ setAttributes:faultCodeAttributes range:NSMakeRange(0,faultCode_.length)];
    
    NSMutableAttributedString * faultCodeVal_ = [[NSMutableAttributedString alloc] initWithString:faultCodeVal];
    NSDictionary * faultCodeValAttributes = @{NSFontAttributeName:[UIFont systemFontOfSize:14],NSForegroundColorAttributeName:[UIColor darkGrayColor],};
    [faultCodeVal_ setAttributes:faultCodeValAttributes range:NSMakeRange(0,faultCodeVal_.length)];
    [faultCode_ appendAttributedString:[[NSMutableAttributedString alloc] initWithString:@"\n"]];
    [faultCode_ appendAttributedString:faultCodeVal_];
    
    return faultCode_;
}

@end
